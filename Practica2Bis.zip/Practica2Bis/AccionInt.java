import java.awt.event.*;
public interface AccionInt {
	public void accion(int n, ActionEvent e);
}


